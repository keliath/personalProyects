$(document).ready(function(){
    $(":submitss").click(function(){
        alert('asd');
        $(":submit").prop("disabled", false); 
    }); 
});

enviando = false; //Obligaremos a entrar el if en el primer submit

function checkSubmit() {
    if (!enviando) {
        enviando= true;
        return true;
    } else {
        //Si llega hasta aca significa que pulsaron 2 veces el boton submit
        return false;
    }
    }