<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/security.php");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <?php include("includes/head.php"); ?>
</head>
<body>
   <?php
    include("includes/header.php");
    include("includes/menu.php");
    ?>
    
    <main>
    <div class="container">
        <h2>DATOS INFORMATIVOS</h2>
        <hr>    
        <p><b>Institución: </b>UNIDAD EDUCATIVA “CIUDAD DE QUEVEDO”</p>
        <div class="row">
            <div class="col-sm-4">
                <p><b>Zona: </b>5</p>
            </div>
            <div class="col-sm-4">
                <p><b>Distrito: </b>3</p>
            </div>
            <div class="col-sm-4">
                <p><b>Circuito: </b>18</p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
               <p><b>Código AMIE: </b>12H02076</p>
                <p><b>Provincia: </b>LOS RÍOS</p>
                <p><b>Cantón: </b>QUEVEDO</p>
                <p><b>Parroquia: </b>“VENUS DEL RIO QUEVEDO”</p>
                <p><b>Dirección: </b>KM 2 ½ VÍA QUEVEDO-BUENA FE</p>
                <p><b>E-mail: </b>colegiomunicipal2008@hotmail.com <br><span>eebciudaddequevedoquevedo@gmail.com</span></p>
                <p><b>Sostenimiento: </b>MUNICIPAL</p>
                <p><b>Ciclos: </b>EDUCACIÓN GENERAL BÁSICA SUPERIOR Y BACHILLERATO</p>
                <p><b>Figuras Profesionales: </b>APLICACIONES INFORMÁTICAS Y DISEÑO
                GRAFICO</p>
                <p><b>Jornada: </b>MATUTINA</p><br>
                <div class="row">
                    <div class="col-sm-4"><b>Número de Estudiantes: </b>577</div>
                    <div class="col-sm-4"><b>Hombres: </b>288</div>
                    <div class="col-sm-4"><b>Mujeres: </b>289</div>
                </div>
                <br>
                <p><b>Número de Directivos: </b>3</p>
                <p><b>Número de Docentes: </b>29</p>
                <p><b>Número de Administrativos: </b>2</p>
                <p><b>Número de Auxiliares de Servicios: </b>1</p>
                <p><b>Número de guardias: </b>3</p>
                <p><b>TOTAL PERSONAL : </b>38</p>
            </div>
        </div>
    </div>
    <div class="body"></div> 
    </main>
    
    <?php
    include("includes/foot.php");
    ?>
</body>
</html>