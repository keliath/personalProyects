<?php
if(!isset($_SESSION)){
    session_start();
}

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/securitypro.php");

$idEva = $_GET["eva"];
$nPregun = '';
$acc = 1;
$user = $_SESSION["user"];

$sql_eval = "SELECT eva_pregun FROM evaluacion where id_evalua = $idEva";
$q_eval = mysqli_query($mysqli, $sql_eval);
$r_eval = mysqli_fetch_assoc($q_eval);
$nPregun = $r_eval["eva_pregun"];

$sql_pregunta = "select * from pregunta where id_evalua = $idEva";
$q_pregunta = mysqli_query($mysqli, $sql_pregunta);
$r_pregunta = mysqli_fetch_assoc($q_pregunta);

if($nPregun != mysqli_num_rows($q_pregunta)){
    header("location:./gestevas.php?inc");
}

if(isset($_GET["id"])){
    $idEvalua = $_GET["id"];
    $nPregun = $_GET["n"];
}
$fin = $nPregun -1;

if(isset($_POST["fin"])){
    
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <?php
        include_once("./includes/head.php");
        ?>

    </head>
    <body>
        <?php
        include("./includes/header.php");
        include("./includes/menu.php");
        ?>

        <main>
            <div class='container' style='margin-top:30px;background-color: rgb(255, 255, 255, 0.9)'>
                <div class='row'>
                    <div class='col-sm-12'>
                        <ul class='nav nav-pills' id='formtab'>
                            <?php
                            $acc = 1;
                            for($x = 1; $x <= $nPregun; $x++){
                                echo "<li class='nav-item'>
                                <a class='nav-link' data-toggle='pill' href='#p$acc'>Pregunta $acc</a>
                                </li>";
                                $acc ++;
                            }
                            ?>

                        </ul>

                        <form action='' method='post'>
                            <div class='tab-content'>
                                <?php
                                $acc2 = 1;
                                $array = array();
                                $pregun = array();
                                do{
                                    $pregunta = $r_pregunta['pre_pregun'];
                                    $idPregun = $r_pregunta['id_pregun'];

                                    $sql_op = "select opc_opcion from opciones where id_pregun = '$idPregun'";
                                    $q_op = mysqli_query($mysqli, $sql_op) or die(mysqli_error($mysqli));

                                    $sql_res = "select res_respuesta from respuesta where id_pregun = '$idPregun'";
                                    $q_res = mysqli_query($mysqli, $sql_res);
                                    $r_res = mysqli_fetch_assoc($q_res);

                                    while($r_op = mysqli_fetch_assoc($q_op)) {
                                        $array[] = $r_op["opc_opcion"];
                                    }
                                    $array[] = $r_res["res_respuesta"];
                                    echo"
                                <div class='tab-pane' id='p$acc2'>
                                    <div class='form-group'>
                                        <label for='pregunta'>Pregunta: $acc2</label>
                                        <textarea class='form-control' name='pregunta' id='pregunta' cols='30' rows='5' required readonly >$pregunta</textarea>
                                    </div>
                                    <div class='input-group mb-3'>
                                        <div class='input-group-prepend'>
                                            <div class='input-group-text'>
                                                <input type='radio' name='correcta$acc2' value='op1'> 
                                            </div>
                                        </div>
                                        <input type='text' name='op1$acc2' class='form-control' placeholder='Opcion 1' autocomplete='off' required readonly value='$array[0]'>
                                    </div>
                                    <div class='input-group mb-3'>
                                        <div class='input-group-prepend'>
                                            <div class='input-group-text'>
                                                <input type='radio' name='correcta$acc2' value='op2'> 
                                            </div>
                                        </div>
                                        <input type='text' name='op2$acc2' class='form-control' placeholder='Opcion 1' autocomplete='off' required readonly value='$array[1]'>
                                    </div>
                                    <div class='input-group mb-3'>
                                        <div class='input-group-prepend'>
                                            <div class='input-group-text'>
                                                <input type='radio' name='correcta$acc2' value='op3'> 
                                            </div>
                                        </div>
                                        <input type='text' name='op3$acc2' class='form-control' placeholder='Opcion 1' autocomplete='off' required readonly value='$array[2]'>
                                    </div>
                                    <div class='input-group mb-3'>
                                        <div class='input-group-prepend'>
                                            <div class='input-group-text'>
                                                <input type='radio' name='correcta$acc2' value='op4' required> 
                                            </div>
                                        </div>
                                        <input type='text' name='op4$acc2' class='form-control' placeholder='Opcion 1' autocomplete='off' required readonly value='$array[3]' style='background-color:palegreen'>
                                    </div>
                                    <a href='./gestevas.php' class='btn btn-primary' style='text-decoration:none'>Volver</a>
                                    </div>";
                                    $acc2++;
                                    $array = array();
                                }while($r_pregunta = mysqli_fetch_assoc($q_pregunta));
                                ?>

                                <div class='tab-pane' id='p'>

                                </div>    
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
        <?php
        require_once("./includes/sweetalertas.php");
        include("./includes/foot.php"); 
        ?>

        <script>
            $('#formtab a').click(function (e) {
                e.preventDefault();
                $(this).tab('show');
            })
        </script>
    </body>
</html>

