<?php
    include("./includes/menupro.php");
?>
   <header class="jumbotron jumbotron-fluid text-center text-white custom-color" style="margin-bottom:0; height:100px">
    <img src="./images/escudoM.png" alt="">
    <h1>Unidad Educativa Municipal Ciudad de Quevedo</h1>
    <img src="./images/escudoU.png" alt="">
</header>

