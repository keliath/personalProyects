<div class="info">
    <div class="container">
        <span>+593 5 2798-199</span>
        <div class="texto">
            <a href="mision.php">Quienes somos</a>
            <a href="datosinfo.php">Info</a>
            <a href="administracion.php">Administración</a>
        </div>
    </div>
    <hr style="margin:5px 0px">
</div>