<?php
session_start();

require_once("../clases/conexion.php");
require("../clases/valida.php");
require("../clases/security.php");

$estu = $_POST["usu"];
$dat = $estu."%";
$sql_estu = "select * from usuarios where (usu_nombre like '$dat' or usu_cedula like '$dat') and usu_nivel = 'estudiante'";
$q_estu = mysqli_query($mysqli,$sql_estu);
$r_estu = mysqli_fetch_assoc($q_estu);
?>


<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <form action="">
                <div class="form-group">
                    <?php
                    if(mysqli_num_rows($q_estu) > 0){
                    ?>
                    <table class="tabla">
                        <thead>
                            <tr>
                                <th>Estudiante</th>
                                <th>Cedula</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                        do{
                            $nom = $r_estu['usu_nombre'];
                            $ci = $r_estu['usu_cedula'];
                            echo 
                                "<tr>
                                    <td>$nom</td>
                                    <td>$ci</td>
                                    <td>
                                        <a href = './repototalestu.php?est=$ci'>Ver notas</a>
                                    </td>
                                </tr>";
                        }while($r_estu = mysqli_fetch_assoc($q_estu));
                            ?>
                        </tbody>
                    </table>
                    <?php

                    }else{
                        echo "No hay registros disponibles";
                    }
                    ?>
                </div>
                <div class="form-group" id="display">
                </div>
            </form>
        </div>
    </div>
</div>