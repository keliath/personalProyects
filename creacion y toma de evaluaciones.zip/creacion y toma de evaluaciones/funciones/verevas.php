<?php


$user = $_SESSION["user"];
$sql_profe = "select id_profes from profesor a inner join usuarios b on a.usu_cedula = b.usu_cedula where b.usu_cedula = '$user'";
$q_profe = mysqli_query($mysqli, $sql_profe);
$r_profe = mysqli_fetch_assoc($q_profe);
$idProfe = $r_profe["id_profes"];

$sql_evas = "select a.id_evalua, id_profes, eva_nombre, eva_pregun, a.eva_fecha,eva_fechaf,ifnull(id_nota,0) as nota from evaluacion a left join nota b on a.id_evalua = b.id_evalua where ifnull(id_nota,0) = 0 order by a.id_evalua desc";
$q_evas = mysqli_query($mysqli, $sql_evas);
$r_evas = mysqli_fetch_assoc($q_evas);


?>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <form action="">
                <div class="form-group">
                    <?php
                    if(mysqli_num_rows($q_evas) > 0){
                    ?>
                    <?php
                        do{
                            $nom = $r_evas['eva_nombre'];
                            $id = $r_evas['id_evalua'];
                            $fechaInicial = $r_evas['eva_fechaf'];
                            $fechaActual = date("Y-m-d H:i:s");
                            $diff = abs(strtotime($fechaActual) - strtotime($fechaInicial));

                            /*$years = floor($diff / (365*60*60*24));
                            $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                            $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));*/
                            
                            $horas = floor($diff / (60*60));
                            $minutos = floor(($diff - $horas * 60*60)/(60));
                            $seg = floor(($diff - $horas * 60*60 - $minutos * 60));
                            $texto = "";
                            
                            if($fechaActual > $fechaInicial){
                                $texto = "<h5 id='time' style='color:red'>Tiempo de atraso: $horas horas $minutos minutos $seg segundos</h5>";
                            }else{
                                $texto = "<h5 id='time'>Limite de tiempo: $horas horas $minutos minutos $seg segundos</h5>";
                            }
                            echo 
                                "<div class='contenedor'>
                                    <h2>Prueba: $nom</h2>
                                    <span>Creada el: $fechaActual</span>
                                    $texto
                                    <a href='./evaluar.php?eva=$id' class='btn btn-primary'>Evaluar</a>
                                </div>";
                        }while($r_evas = mysqli_fetch_assoc($q_evas));

                    }else{
                        echo "No hay evaluaciones";
                    }
                    ?>
                </div>
                <div class="form-group" id="display">
                </div>
            </form>
        </div>
    </div>
</div>




