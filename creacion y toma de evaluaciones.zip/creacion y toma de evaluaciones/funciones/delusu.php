<?php
session_start();

require_once("../clases/conexion.php");
require("../clases/valida.php");
require("../clases/security.php");

if($_SESSION["nivel"]!='profesor'){
    header("location:./?sec");
    exit;
}

$usu = $_GET["usu"];

$sql_del = "delete from usuarios where usu_cedula = '$usu'";
$q_del = mysqli_query($mysqli, $sql_del);

header("location:../lista.php");