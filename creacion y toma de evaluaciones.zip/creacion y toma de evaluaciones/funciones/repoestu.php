<?php
$user = $_SESSION["user"];

$sql_repo = "select id_nota, a.id_evalua,a.usu_cedula, not_nota,eva_nombre, eva_pregun, a.eva_fecha,eva_fechaf from nota a inner join evaluacion b on a.id_evalua = b.id_evalua where usu_cedula = '$user' group by id_evalua desc";
$q_repo = mysqli_query($mysqli, $sql_repo);
$r_repo = mysqli_fetch_assoc($q_repo);

?>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <form action="">
                <div class="form-group">
                    <?php
                    if(mysqli_num_rows($q_repo) > 0){
                    ?>
                    <table class="tabla">
                        <thead>
                            <tr>
                                <th>Evaluación</th>
                                <th>Nota</th>
                                <th>Atrasada</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                        do{
                            $nom = $r_repo['eva_nombre'];
                            $nota = $r_repo['not_nota'];
                            $max = 10;
                            $fechaR = $r_repo["eva_fecha"];
                            $fechaI = $r_repo["eva_fechaf"];
                            $diff = abs(strtotime($fechaR) - strtotime($fechaI));
                            $atraso = "no";
                            if($diff > 0){
                                
                            }else{
                                $atraso = "si";
                            }
                            
                            echo 
                                "<tr>
                                    <td>$nom</td>
                                    <td>$nota/$max</td>
                                    <td>$atraso</td>
                                </tr>";
                        }while($r_repo = mysqli_fetch_assoc($q_repo));
                            ?>
                        </tbody>
                    </table>
                    <?php
                        echo "<a href='./' class='btn btn-primary' style='text-decoration:none'>Volver</a>";

                    }else{
                        echo "No hay evaluaciones resueltas, de click <a href='./evas.php'>aquí</a> para ver las evaluaciones disponibles";
                    }
                    ?>
                </div>
                <div class="form-group" id="display">
                </div>
            </form>
        </div>
    </div>
</div>