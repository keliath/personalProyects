<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/security.php");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <?php include("includes/head.php"); ?>
</head>
<body>
   <?php
    include("includes/header.php");
    include("includes/menu.php");
    ?>
    
    <main>
       <div class="container">
           <?php
        if($_SESSION["nivel"] == "profesor"){
           ?>
            <input type='text' class='form-control' placeholder='Buscar' oninput="ajax('./ajax/repo.php','display',this)">
            <div id='display'></div>
        <?php
        }else{
            include("./funciones/repoestu.php");
        }
        ?>
       </div>
        
    </main>
    
    <?php
    include("includes/foot.php");
    include("includes/sweetalertas.php");
    ?>
</body>
</html>