<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/securitypro.php");

$sql_activa = "select * from usuarios where usu_activo = 0";
$q_activa = mysqli_query($mysqli, $sql_activa);
$r_activa = mysqli_fetch_assoc($q_activa);

if(isset($_POST["registrar"])){
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <?php
        include_once("./includes/head.php");
        ?>
    </head>
    <body class="">
        <?php
        include("./includes/header.php");
        include("./includes/menu.php");
        ?>

        <main>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <form action="">
                            <div class="form-group">
                                <?php
                                if(mysqli_num_rows($q_activa) > 0){
                                ?>
                                <table class="tabla">
                                    <thead>
                                        <tr>
                                            <th>Estudiante</th>
                                            <th>Cédula</th>
                                            <th>Opciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                    do{
                                        $nom = $r_activa['usu_nombre'];
                                        $id = $r_activa['usu_cedula'];
                                        echo 
                                            "<tr>
                                                        <td>$nom</td>
                                                        <td>$id</td>
                                                        <td>
                                                            <a href='./funciones/valest.php?est=$id' class='btn btn-primary' style='text-decoration:none'>
                                                                Registrar
                                                            </a>
                                                        </td>
                                                    </tr>";
                                    }while($r_activa = mysqli_fetch_assoc($q_activa));
                                        ?>
                                    </tbody>
                                </table>
                                <?php
                                    echo "<br><a href='./' class='btn btn-primary' style='text-decoration:none'>Volver</a>";

                                }else{
                                    echo "No hay registro de estudiantes pendientes.";
                                }
                                ?>
                            </div>
                            <div class="form-group" id="display">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>

        <?php
        require_once("./includes/sweetalertas.php");
        ?>
    </body>
</html>