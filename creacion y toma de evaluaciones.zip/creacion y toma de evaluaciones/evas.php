<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/security.php");

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <?php
        include_once("./includes/head.php");
        ?>
    </head>
    <body class="">
        <?php
        include("./includes/header.php");
        include("./includes/menu.php");
        ?>

        <main>
            <?php
            include("./funciones/verevas.php");
            ?>
        </main>

        <?php
    include("includes/foot.php");
    include("includes/sweetalertas.php");
    ?>
    </body>
</html>