<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/securitypro.php");

$sql_lista = "select * from usuarios where usu_nivel = 'estudiante'";
$q_lista = mysqli_query($mysqli, $sql_lista);
$r_lista = mysqli_fetch_assoc($q_lista);
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <?php
        include_once("./includes/head.php");
        ?>
    </head>
    <body>
        <?php
        include_once("./includes/header.php");
        include_once("./includes/menu.php");
        ?>

        <main>
            <div class="container">
                <table class="tabla">
                   <?php
                    if(mysqli_num_rows($q_lista)){
                    ?>
                    <thead>
                        <th>Estudiante</th>
                        <th>Cédula</th>
                        <th>Opciones</th>
                    </thead>
                    <tbody>
                        <?php
                        do{
                            $nombre = $r_lista["usu_nombre"];
                            $ced = $r_lista["usu_cedula"];
                            echo"
                                <td>$nombre</td>
                                <td>$ced</td>
                                <td>
                                    <a href='./funciones/delusu.php?usu=$ced' class='btn btn-danger' style='text-decoration:none'>
                                        Borrar
                                    </a>
                                </td>
                            ";
                        }while($r_lista = mysqli_fetch_assoc($q_lista));
                        }else{
                            echo "No hay estudiantes registrados";
                        }
                        
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </body>
</html>