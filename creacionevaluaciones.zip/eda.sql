-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-06-2020 a las 12:35:22
-- Versión del servidor: 10.1.45-MariaDB-cll-lve
-- Versión de PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyectsistemas_dweb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evaluacion`
--

CREATE TABLE `evaluacion` (
  `id_evalua` int(11) NOT NULL,
  `id_profes` int(11) NOT NULL,
  `eva_nombre` varchar(256) NOT NULL,
  `eva_pregun` int(11) NOT NULL,
  `eva_fecha` datetime NOT NULL,
  `eva_fechaf` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `evaluacion`
--

INSERT INTO `evaluacion` (`id_evalua`, `id_profes`, `eva_nombre`, `eva_pregun`, `eva_fecha`, `eva_fechaf`) VALUES
(33, 5, 'prueba 1', 3, '2019-08-16 16:28:45', '2019-08-16 16:39:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nota`
--

CREATE TABLE `nota` (
  `id_nota` int(11) NOT NULL,
  `id_evalua` int(11) NOT NULL,
  `usu_cedula` varchar(13) NOT NULL,
  `eva_fecha` datetime NOT NULL,
  `not_nota` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `nota`
--

INSERT INTO `nota` (`id_nota`, `id_evalua`, `usu_cedula`, `eva_fecha`, `not_nota`) VALUES
(21, 33, '1206246744', '2019-08-16 16:34:29', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opciones`
--

CREATE TABLE `opciones` (
  `id_opcion` int(11) NOT NULL,
  `id_pregun` int(11) NOT NULL,
  `opc_opcion` varchar(512) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `opciones`
--

INSERT INTO `opciones` (`id_opcion`, `id_pregun`, `opc_opcion`) VALUES
(102, 37, 'ergerg'),
(103, 37, 'egre'),
(104, 37, 'ergeg'),
(105, 38, 'ergeger'),
(106, 38, 'ergerg'),
(107, 38, 'ergerg'),
(108, 39, 'regerg'),
(109, 39, 'ergerg'),
(110, 39, 'ergerg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opescogida`
--

CREATE TABLE `opescogida` (
  `id_opesco` int(11) NOT NULL,
  `id_pregun` int(11) NOT NULL,
  `usu_cedula` varchar(13) NOT NULL,
  `ope_opcion` varchar(512) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `opescogida`
--

INSERT INTO `opescogida` (`id_opesco`, `id_pregun`, `usu_cedula`, `ope_opcion`) VALUES
(66, 37, '1206246744', 'egre'),
(67, 38, '1206246744', 'ergerg'),
(68, 39, '1206246744', 'ergerge2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta`
--

CREATE TABLE `pregunta` (
  `id_pregun` int(11) NOT NULL,
  `id_evalua` int(11) NOT NULL,
  `pre_pregun` varchar(512) NOT NULL,
  `pre_tipo` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `pregunta`
--

INSERT INTO `pregunta` (`id_pregun`, `id_evalua`, `pre_pregun`, `pre_tipo`) VALUES
(37, 33, 'hergergergreg', 'multiple'),
(38, 33, '2gegre', 'multiple'),
(39, 33, 'gregergerg', 'multiple');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `id_profes` int(11) NOT NULL,
  `usu_cedula` varchar(13) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`id_profes`, `usu_cedula`) VALUES
(5, 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuesta`
--

CREATE TABLE `respuesta` (
  `id_respue` int(11) NOT NULL,
  `id_pregun` int(11) NOT NULL,
  `res_respuesta` varchar(512) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `respuesta`
--

INSERT INTO `respuesta` (`id_respue`, `id_pregun`, `res_respuesta`) VALUES
(34, 37, 'rgerge'),
(35, 38, 'ergergerg111'),
(36, 39, 'ergerge2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `usu_cedula` varchar(13) NOT NULL,
  `usu_mail` varchar(128) NOT NULL,
  `usu_pass` varchar(64) NOT NULL,
  `usu_nombre` varchar(64) NOT NULL,
  `usu_nivel` varchar(32) NOT NULL DEFAULT 'estudiante',
  `usu_vercod` varchar(128) DEFAULT NULL,
  `usu_activo` int(11) NOT NULL DEFAULT '0',
  `usu_status` int(11) NOT NULL DEFAULT '0',
  `usu_change` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usu_cedula`, `usu_mail`, `usu_pass`, `usu_nombre`, `usu_nivel`, `usu_vercod`, `usu_activo`, `usu_status`, `usu_change`) VALUES
('admin', 'mail1@gmail.com', 'e1d5be1c7f2f456670de3d53c7b54f4a', 'admin', 'profesor', '30f57554f54203afb3cff405f825acfa', 1, 1, 0),
('1206246744', 'roan771996@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'andres', 'estudiante', '5d57206a053e7', 1, 1, 0),
('1206205591', 'abraham@hotmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Abraham', 'estudiante', '5d5aac001a28b', 1, 1, 0),
('1250587266', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'ALARCON ALVARADO EVELYN ADRIANA', 'estudiante', '5d708aca61e1f', 1, 1, 0),
('1207334085', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'ARAUJO MUÑOZ JEAN CARLOS', 'estudiante', '5d708b06a7d19', 1, 0, 0),
('1206553313', 'Estudiante', '8a13dab3f5ec9e22d0d1495c8c85e436', 'AVILA RODRIGUEZ MAYRENE FERNANDA', 'estudiante', '5d708b3228243', 1, 0, 0),
('1206475921', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'AVILA RODRIGUEZ MELANNY FERNANDA', 'estudiante', '5d708b834fe97', 1, 0, 0),
('1350553515', 'Estudiante', '14f9518c8b937874621f29425161acec', 'AVILA ROSADO MARCELO EDUARDO', 'estudiante', '5d708ba00b801', 1, 0, 0),
('1206331439', 'Estudiante', 'e1d5be1c7f2f456670de3d53c7b54f4a', 'BARBOTO CADENA MARIA BRIGITTE', 'estudiante', '5d708bc5604b6', 1, 0, 0),
('1204497521', 'Estudiante', 'e1d5be1c7f2f456670de3d53c7b54f4a', 'BARRERA ROSADO TIONY DENISSE', 'estudiante', '5d708bea4cb3d', 1, 0, 0),
('1250072566', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'CABEZAS GUZMAN KAREN NOHELIA', 'estudiante', '5d708c0bac54f', 1, 0, 0),
('1204796369', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'CABEZAS QUIÑONEZ MAYERLI ELOISA', 'estudiante', '5d708c271d397', 1, 0, 0),
('1200561155', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'CAMINO SUAREZ ADRIANA LIZBETH', 'estudiante', '5d708c4328331', 1, 0, 0),
('1207454875', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'CARRERA BASURTO ALLISON JAMILETH', 'estudiante', '5d708c58709dd', 1, 0, 0),
('1206860650', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'COBOS BRITO ZULEY BRITHANY ', 'estudiante', '5d708c73995c6', 1, 0, 0),
('1206600767', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'FRANCO ZAMORA EVER JOSUE', 'estudiante', '5d708c8a31ecb', 1, 0, 0),
('0702225756', ' Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'GUEVARA VASQUEZ MELISSA KAROLAY', 'estudiante', '5d708ca395031', 1, 0, 0),
('1201718812', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'MERCHAN RIVAS DANNY ALEXANDER', 'estudiante', '5d708cc94a3ee', 1, 0, 0),
('1307367704', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'MOREIRA MENA BRITANY TATIANA', 'estudiante', '5d708cdfd18c8', 1, 0, 0),
('1207435239', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'ORELLANA LEAL VICTOR ELIAS', 'estudiante', '5d708cfb401c6', 1, 0, 0),
('1206606772', ' Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'PEÑA CASTRO GEORGE MARCELO', 'estudiante', '5d708d47dffef', 1, 0, 0),
('1709017022', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'PERALTA LAAZ MELANYA YAMELL', 'estudiante', '5d708d6ada647', 1, 0, 0),
('1202333181', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'RAMIREZ ESPINOZA CARMEN LISBETH', 'estudiante', '5d708dadf2b25', 1, 0, 0),
('1309161477', 'Estudiante', 'e1d5be1c7f2f456670de3d53c7b54f4a', 'ROJAS PACHECO NADIA ESTEFANIA', 'estudiante', '5d708dc2ca441', 1, 0, 0),
('1202500391', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'SALTOS ALVARADO EMERSON STEVEN', 'estudiante', '5d708dddbb065', 1, 0, 0),
('1203331887', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'SANTOS TORRES DAYANARA EMILY', 'estudiante', '5d708df656f69', 1, 0, 0),
('1250906888', 'Estudiante', '81dc9bdb52d04dc20036dbd8313ed055', 'TORRES ALAVA JOSELYN MAYERLY', 'estudiante', '5d708e105faab', 1, 0, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `evaluacion`
--
ALTER TABLE `evaluacion`
  ADD PRIMARY KEY (`id_evalua`);

--
-- Indices de la tabla `nota`
--
ALTER TABLE `nota`
  ADD PRIMARY KEY (`id_nota`);

--
-- Indices de la tabla `opciones`
--
ALTER TABLE `opciones`
  ADD PRIMARY KEY (`id_opcion`);

--
-- Indices de la tabla `opescogida`
--
ALTER TABLE `opescogida`
  ADD PRIMARY KEY (`id_opesco`);

--
-- Indices de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD PRIMARY KEY (`id_pregun`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`id_profes`);

--
-- Indices de la tabla `respuesta`
--
ALTER TABLE `respuesta`
  ADD PRIMARY KEY (`id_respue`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usu_cedula`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `evaluacion`
--
ALTER TABLE `evaluacion`
  MODIFY `id_evalua` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de la tabla `nota`
--
ALTER TABLE `nota`
  MODIFY `id_nota` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `opciones`
--
ALTER TABLE `opciones`
  MODIFY `id_opcion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT de la tabla `opescogida`
--
ALTER TABLE `opescogida`
  MODIFY `id_opesco` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT de la tabla `pregunta`
--
ALTER TABLE `pregunta`
  MODIFY `id_pregun` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de la tabla `profesor`
--
ALTER TABLE `profesor`
  MODIFY `id_profes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `respuesta`
--
ALTER TABLE `respuesta`
  MODIFY `id_respue` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
