<?php
require_once("./clases/conexion.php");

$id = $_GET['id'];
$sql_idPre = "select id_pregun from pregunta where id_evalua = $id";
$q_idPre = mysqli_query($mysqli, $sql_idPre);
$r_idPre = mysqli_fetch_assoc($q_idPre);

do{
    $idPre = $r_idPre["id_pregun"];
    $sql_delop1 = sprintf("Delete from opciones where id_pregun = $idPre");
    $q_delop1 = mysqli_query($mysqli, $sql_delop1);
    $sql_delop2 = sprintf("delete from respuesta where id_pregun = $idPre");
    $q_delop2 = mysqli_query($mysqli, $sql_delop2);
    $sql_delop3 = sprintf("delete from opescogida where id_pregun = $idPre");
    $q_delop3 = mysqli_query($mysqli, $sql_delop3);
}while($r_idPre= mysqli_fetch_assoc($q_idPre));

$sql_deleva = sprintf("Delete from evaluacion where id_evalua = $id;");
$q_deleva = mysqli_query($mysqli, $sql_deleva);
$sql_deleva = sprintf("Delete from pregunta where id_evalua = $id;");
$q_deleva = mysqli_query($mysqli, $sql_deleva);

header("location:./gestevas.php");