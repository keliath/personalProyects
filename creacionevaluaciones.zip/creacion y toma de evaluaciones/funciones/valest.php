<?php
session_start();

require_once("../clases/conexion.php");
require("../clases/valida.php");

$est = $_GET["est"];

$sql_activa = "UPDATE usuarios SET usu_activo = 1 where usu_cedula = '$est'";
$q_activa = mysqli_query($mysqli, $sql_activa);

header("location:../regest.php");
