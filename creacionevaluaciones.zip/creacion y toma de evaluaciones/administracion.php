<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/security.php");

?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <?php include("includes/head.php"); ?>
    </head>
    <body>
        <?php
        include("includes/header.php");
        include("includes/menu.php");
        ?>

        <main>
            <div class="container">
                <h2>ORGANIZACIÓN ADMINISTRATIVA</h2>
                <hr>
                <center>
                    <img src="./images/rector.jpg" alt="rector" class="textob">
                    <p >
                        <b>Víctor Hugo Acosta Moreira</b>
                    </p>
                    <p >
                        Rector del Colegio Municipal  
                    </p>
                    <p>
                        MSC. Proyectos Educativos
                    </p>
                    <p >
                        LCDO. Ciencias de la Educación
                    </p>
                </center><br>
                <p class="textob">
                    <b>Vicerrector: </b>MSc. TANIA JACHO MACÎAS <br>
                    <b>Inspector General: </b>LCDO. EDISON CHEVEZ <br>
                    <b>Secretaria: </b>ING. MARJORIE FUENTES CABRERA <br>
                </p>
                <p class="textob"><b>GOBIERNO ESCOLAR </b></p>
                <p class="textob">
                    <b>Rector: </b>MSC. MILTON ALBIÑO ORTEGA<br>
                    <b>Delegado de Estudiantes: </b>SRTA. DIXY RAFAELA GARCÍA ZAMBRANO<br>
                    <b>Delegado padres de familia: </b>SRA. GABRIELA MARITZA LEMA MACKENCEN<br>
                    <b>Delegado de los Docentes: </b>ING. VICTOR SANCHEZ ALVARADO.<br>
                </p>
                <p class="textob"><b>CONSEJO EJECUTIVO</b></p>
                <p class="textob">
                    <b>Rector </b>LCD. MILTON MIGUEL ALBIÑO MSc.<br>
                    <b>Vicerrector </b>ING. TANIA ELIZABETH JACHO MACÌAS MSc<br>
                    <b>Primer vocal LIC. </b>ARQ. CAROLINA MARITZA OCAÑA CORTEZ<br>
                    <b>Tercer Vocal </b>MSc. LETICIA VELIZ INTRIAGO<br>
                </p>
                <p class="textob"><b>ASOCIACIÓN ESTUDIANTIL</b></p>
                <p class="textob">
                    <b>Presidenta: </b>SRTA. DIXY RAFAELA GARCÍA ZAMBRANO<br>
                    <b>Vicepresidenta: </b>SRTA. MELINA JIBELL MOREJÓN RODRÍGUEZ<br>
                    <b>Tesorera: </b>SRTA. ANGIE MALLERLY VILLEGAS CASTRO<br>
                    <b>Secretaria:</b>SRTA. MÓNICA SALOMÉ RUIZ ZAMBRANO<br>
                    <b>Vocal Principal:</b>SRTA. LINDA VICTORIA TORRES CEDEÑO<br>
                    <b>Vocal Principal: </b>SRTA. NADIA ESTEFANÍA ROJAS PACHECO<br>
                </p>
                <p class="textob"><b>COMITÉ CONSULTIVO PARA LA CONSTRUCCIÓN DEL CÓDIGO DE CONVIVENCIA.</b></p>
                <p class="textob">
                    <b>Msc. Milton Albiño Ortega </b>Rector<br>
                    <b>Ing. Tania Jacho Macías </b>Vicerrectora<br>
                    <b>Lcdo. Edison Chévez Mera </b>Inspector General<br>
                    <b>Psic. Edu. Alex Salvatierra V </b>Equipo gestor DECE<br>
                    <b>Ing. Víctor Sánchez Alvarado </b>Equipo gestor DOCENTE<br>
                    <b>Lcda. Ilenia Pérez Román </b>Equipo gestor DOCENTE<br>
                </p>
            </div>
            
        </main>

        <?php
        include("includes/foot.php");
        ?>
    </body>
</html>