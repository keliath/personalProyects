<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'vinculacion';

$userO = "proyectsistemas_dweb";
$passO = "proyectsistemas_dweb";
$dbO = "proyectsistemas_dweb";

$hol = 0;

date_default_timezone_set("America/Guayaquil");

if($hol == 1){
    $mysqli = mysqli_connect($host, $userO, $passO, $dbO);
}else{
    $mysqli = mysqli_connect($host, $user, $pass, $db);
}

if(!$mysqli){
}
