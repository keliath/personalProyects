<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/security.php");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <?php include("includes/head.php"); ?>
</head>
<body>
   <?php
    include("includes/header.php");
    include("includes/menu.php");
    ?>
    
    <main>
      <div class="container">
          <h2>Material didáctico</h2>
          <hr>
        <a href="https://mega.nz/#!h5tDmawB!esy6tx6dqpkAaqbemjB_3X4tVuK9B2bj9IgNaqegJ-E" class="btn btn-primary" target="_blank">Descagar</a>
      </div>
       
    </main>
    
    <?php
    include("includes/foot.php");
    include("includes/sweetalertas.php");
    ?>
</body>
</html>