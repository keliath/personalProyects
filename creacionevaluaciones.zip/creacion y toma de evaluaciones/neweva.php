<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/securitypro.php");

$user = $_SESSION["user"];
$sql_profe = "select id_profes from profesor a inner join usuarios b on a.usu_cedula = b.usu_cedula where b.usu_cedula = '$user'";
$q_profe = mysqli_query($mysqli, $sql_profe);
$r_profe = mysqli_fetch_assoc($q_profe);
$idProfe = $r_profe["id_profes"];

if(isset($_POST["crear"])){
    $date = date("Y-m-d H:i:s");
    $finalDate = $_POST["fechaf"];
    $finalDate = date("Y-m-d H:i:s", strtotime($finalDate));
    $sql_newe = sprintf("INSERT INTO evaluacion (id_profes, eva_nombre, eva_pregun, eva_fecha, eva_fechaf) values (%s, %s, %s, %s, %s)",
                        valida::convertir($mysqli, $idProfe, "int"),
                        valida::convertir($mysqli, $_POST["name"], "text"),
                        valida::convertir($mysqli, $_POST["np"], "int"),
                        valida::convertir($mysqli, $date, "date"),
                        valida::convertir($mysqli, $finalDate, "date"));
    $q_newe = mysqli_query($mysqli, $sql_newe);
    $id_newe = mysqli_insert_id($mysqli);
    header("location:./newpre.php?ide=$id_newe");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <?php
        include_once("./includes/head.php");
        ?>

        <script type = "text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script type = "text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
        <script type = "text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/js/tempusdominus-bootstrap-4.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/css/tempusdominus-bootstrap-4.min.css" />
    </head>
    <body class="">
        <?php
        include("./includes/header.php");
        include("./includes/menu.php");
        ?>

        <main>
            <div class='container' style='margin-top:30px'>
                <div class='row'>
                    <div class='col-sm-12'>
                        <form action='' method='post' enctype='multipart/form-data' onsubmit="return checkSubmit()">
                            <div class='form-group'>
                                <h5>Menú de creación de Evaluaciones</h5>
                                <hr class='d-sm-none'>
                            </div>
                            <div class='form-group'>
                                <label for='name'>Nombre de la evaluación:</label>
                                <input type='text' class='form-control' id='name' name='name' autocomplete='off' required>
                            </div>
                            <div class='form-group'>
                                <label for='np'>Número de preguntas:</label>
                                <input type='number' name='np' class='form-control' min='1' max='20' required autocomplete="off">
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class='form-group'>
                                        <label for='fechaf'>fecha final para dar la evaluación:</label>
                                        <div class="input-group date" id="datetimepicker1" data-target-input="nearest">
                                            <input type="text" name="fechaf" class="form-control datetimepicker-input" data-target="#datetimepicker1" data-toggle="datetimepicker"/>
                                            <div class="input-group-append" data-target="#datetimepicker1" data-toggle="datetimepicker">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <button type='submit' class='btn btn-primary' name='crear'>Crear</button>
                        </form>
                    </div>
                </div>
            </div>

        </main>

        <?php
        require_once("./includes/sweetalertas.php");
        ?>

        <script>
            $(function () {
                $('#datetimepicker1').datetimepicker({
                    inline: true,
                    sideBySide: true,
                    locale: 'ec'
                    // minDate: new Date(),
                // minDate: '03/06/2019',
                });
            });
        </script>
    </body>
</html>