<?php
require_once("./clases/conexion.php");
include("./clases/valida.php");

if(isset($_POST["registrar"])){
    $cod = uniqid();
    $sql_registro = sprintf("INSERT INTO usuarios (usu_cedula, usu_mail, usu_nombre,usu_pass, usu_vercod) VALUES (%s, %s, %s, %s,%s)",
                            valida::convertir($mysqli, $_POST["ci"], "text"),
                            valida::convertir($mysqli, $_POST["mail"], "text"),
                            valida::convertir($mysqli, $_POST["nombre"], "text"),
                            valida::convertir($mysqli, md5($_POST["pass"]), "text"),
                            valida::convertir($mysqli, $cod, "text"));
    $q_registro = mysqli_query($mysqli, $sql_registro)or die(mysqli_error($mysqli));

    if($q_registro){
        header("location:./?reg=1");
    }else{
        header("location:./?reg=0");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Registro</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="./css/login.css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

        <script type="text/javascript">
            function validar(obj, obj2) {
                var ci = obj.value;
                var cad = ci.trim();
                var btnreg = document.getElementById("registrar");
                var total = 0;
                var longitud = cad.length;
                var longcheck = longitud - 1;

                if (cad !== "" && longitud === 10 && cad !== "0000000000"){
                    for(i = 0; i < longcheck; i++){
                        if (i%2 === 0) {
                            var aux = cad.charAt(i) * 2;
                            if (aux > 9) aux -= 9;
                            total += aux;
                        } else {
                            total += parseInt(cad.charAt(i)); // parseInt o concatenará en lugar de sumar
                        }
                    }

                    total = total % 10 ? 10 - total % 10 : 0;

                    if (cad.charAt(longitud-1) == total) {
                        document.getElementById("salida").innerHTML = ("");
                        btnreg.removeAttribute('hidden','');
                    }else{
                        document.getElementById("salida").innerHTML = ("Cedula Inválida");
                        btnreg.setAttribute('hidden','');
                    }
                }else{
                    document.getElementById("salida").innerHTML = ("Cedula Inválida");
                    btnreg.setAttribute('hidden','');
                }
            }
        </script>

    </head>
    <body class="body">
        <main>
            <form action="" method="post" style="margin-top:40px">
                <center><h1>Registro</h1></center>
                <input type="text" name="ci" id="ci" placeholder="Ingrese su cedula" onblur="validar(this, registrar)" max="13" required autocomplete="off">
                <div id="salida" class="error"></div>
                <input type="text" name="mail" placeholder="Ingrese su correo" required autocomplete="off">
                <input type="text" name="nombre" placeholder="Ingrese su nombre" required autocomplete="off">
                <input type="password" name="pass" placeholder="Ingrese una contraseña" required autocomplete="off">
                <input type="submit" id="registrar" class="ok" name="registrar" value="Registrar">
                <input type="button" class="cancelbtn" onclick="history.back()" value="Cancelar">
            </form>
        </main>
    </body>
</html>