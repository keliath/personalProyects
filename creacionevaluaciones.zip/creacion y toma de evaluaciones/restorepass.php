<?php
require_once("./clases/valida.php");
require_once("./clases/conexion.php");

$activa = false;

if(isset($_GET["cod"])){
    $code = $_GET["cod"];
    $sql_activa = sprintf("SELECT * FROM usuarios where usu_vercod = %s",
                          valida::convertir($mysqli, $code, "text"));
    $q_activa = mysqli_query($mysqli, $sql_activa);
    $r_activa = mysqli_num_rows($q_activa);

    if($r_activa === 1){
        $activa = true;
    }   
}

if(isset($_POST["restore"])){
    $codigo = md5(uniqid());
    $mail = $_POST["mail"];
    $reg = "";

    $sql_registro = sprintf("update usuarios set usu_vercod = %s",
                            valida::convertir($mysqli, $codigo, "text"));
    $q_registro = mysqli_query($mysqli, $sql_registro) or die ("error: ".mysqli_error($mysqli));

    if($q_registro){
        $res = 1;
    }else{
        $res = 0;
    }

    // Mandar mail por smtp del host
    $mailBody = "Recuperación de contraseña en el\n";
    $mailBody .= "sistema de evaluaciones.\n\n";
    $mailBody .= "ingrese al siguiente enlace\n";
    $mailBody .= "link: http://dweb.proyectsistemas.com/restorepass.php/activar.php?cod=$codigo\n\n";
    $mailBody .= "Si usted no ha solicitado un cambio de contraseña\n";
    $mailBody .= "ignore este correo.";

    $mailAsunto = "Restauracion de contraseña";

    $headers =  'MIME-Version: 1.0' . "\r\n"; 
    $headers .= 'From: proyectsistemas <proyectsistemas@proyectsistemas.com>' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

    if(mail($mail,$mailAsunto,$mailBody)){ 
        $res = 3; 
    }else{ 
        $res = 2; 
    } 


    header("location:./index.php?res=$res");
}

if(isset($_POST["cambio"])){
    $sql_cambio = sprintf("Update usuarios set usu_pass = %s",
                         valida::convertir($mysqli, $_POST["npass"]));
    $q_cambio = mysqli_query($mysqli, $sql_cambio);
    header("location:./?rest");
}

?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Activación</title>
        <?php
        include_once("./includes/head.php");
        ?>
        
        <script>
            function misma(obj, obj2){
                var campo = obj;
                var pass = campo.value;
                var vpass = obj2.value;
                
                if(pass != vpass){
                    document.getElementById("igual").innerHTML = "Las contraseñas deben ser las mismas <br>";
                    campo.style.backgroundColor = "red";
                    document.getElementById("cambio").setAttribute("hidden","");
                }else{
                    document.getElementById("igual").innerHTML = "";
                    campo.style.backgroundColor = "white";
                    document.getElementById("cambio").removeAttribute("hidden","");
                }
            }
        </script>
    </head>
    <body>
       <?php
        include("./includes/header.php");
        include("./includes/menu.php");
        ?>

        <main>
            <?php
            if($activa){
                ?>
                <form action="" method="post">
                    <h3>Cambio de contraseña</h3>
                    <hr>
                    <input type="text" name="npass" id="npass" placeholder="Ingrese una contraseña" style="width:200px;padding:10px 20px;"><br>
                    <input type="text" name="nvpass" id="nvpass" placeholder="Ingrese nuevamente la contraseña" style="width:200px;padding:10px 20px;" onblur="misma(this, npass)"><br>
                    <div class="error" id="igual"></div>
                    <input type="submit" class="ok" style="width:100px" id="cambio" name="cambio" value="Enviar"><br>
                    <a href="./" class="btn ok" style="width:100px">Volver</a>
                </form>
                <?php
            }else{
            ?>
            
            <div class="container">
                <form action="" method="post">
                    <h3>Recuperación de contraseña</h3>
                    <hr>
                    <input type="text" placeholder="Ingrese su correo" name="mail" style="width:200px;padding:10px 20px;">
                    <input type="submit" class="ok" style="width:100px" name="restore" value="Enviar"><br>
                    <a href="./" class="btn ok" style="width:100px">Volver</a>
                </form>
            </div>
            
            <?php
            }
            ?>
            <?php
            require_once("./includes/sweetalertas.php");
            ?>
        </main>

        <?php include("./includes/foot.php"); ?>
    </body>
</html>