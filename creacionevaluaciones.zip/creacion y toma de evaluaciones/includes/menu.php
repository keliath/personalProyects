
<?php //script para mostrar un solo menu en todas las paginas
if(isset($_SESSION['nivel'])){
    $lvl = $_SESSION["nivel"];
    if($_SESSION['nivel'] == 'profesor'){ //condicion que verificara la variable 'nivel' para mostrar ciertas opciones si es admin o no
        echo "<nav class='navbar navbar-expand-lg navbar-dark navbar-custom sticky-top' >
        <ul class='navbar-nav mr-auto'>
            <li class='nav-item'>
                <a class='nav-link' href='./profesor.php'><b>Inicio</b></a>
            </li>
        </ul>
    <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarNavDropdown' aria-controls='navbarNavDropdown' aria-expanded='false' aria-label='Toggle navigation'>
        <span class='navbar-toggler-icon'></span>
    </button>
    <div id='navbarNavDropdown' class='navbar-collapse collapse'>
        <ul class='navbar-nav mr-auto'>
            <li class='nav-item dropdown'>
                <a class='nav-link dropdown-toggle' href='#' id='navbardrop' data-toggle='dropdown'>
                    Evaluaciones
                </a>
                <div class='dropdown-menu'>
                    <a class='dropdown-item' href='./neweva.php'>Crear Evaluación</a>
                    <a class='dropdown-item' href='./gestevas.php'>Gestionar Evaluaciones</a>
                </div>
            </li>
            <li class='nav-item dropdown'>
                <a class='nav-link dropdown-toggle' href='#' id='navbardrop' data-toggle='dropdown'>
                    Estudiantes
                </a>
                <div class='dropdown-menu'>
                    <a class='dropdown-item' href='./regest.php'>Registros</a>
                    <a class='dropdown-item' href='./reportes.php'>Notas</a>
                    <a class='dropdown-item' href='./lista.php'>Lista</a>
                </div>
            </li>
            
         </ul>
        <ul class='navbar-nav'>
            <li class='nav-item'>
                <a class='nav-link' href='material.php'>Materiales de apoyo</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='./clases/close.php'>Cerrar Sesion</a>
            </li>
        </ul>
    </div>
</nav>";
    }else{
        echo "<nav class='navbar navbar-expand-lg navbar-dark navbar-custom sticky-top'>
        <ul class='navbar-nav mr-auto'>
            <li class='nav-item'>
                <a class='nav-link' href='./estudiante.php'><b>Inicio</b></a>
            </li>
        </ul>
    <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarNavDropdown' aria-controls='navbarNavDropdown' aria-expanded='false' aria-label='Toggle navigation'>
        <span class='navbar-toggler-icon'></span>
    </button>
    <div id='navbarNavDropdown' class='navbar-collapse collapse'>
        <ul class='navbar-nav mr-auto'>
            <li class='nav-item'>
                <a class='nav-link' href='./evas.php'>Evaluaciones</a>
            </li>
            <li class='nav-item dropdown'>
                <a class='nav-link dropdown-toggle' href='#' id='navbardrop' data-toggle='dropdown'>
                    Reportes
                </a>
                <div class='dropdown-menu'>
                    <a class='dropdown-item' href='./reportes.php'>Notas</a>
                </div>
                
            </li>
           
         </ul>
        <ul class='navbar-nav'>
            <li class='nav-item'>
                <a class='nav-link' href='material.php'>Materiales de apoyo</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='./clases/close.php'>Cerrar Sesion</a>
            </li>
        </ul>
    </div>
</nav>";
    }
}
?>


