<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/securitypro.php");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <?php include("includes/head.php"); ?>
</head>
<body class="body">
   <?php
    include("includes/header.php");
    include("includes/menu.php");
    ?>
    
    <main>
    <div class="body"></div> 
    </main>
    
    <?php
    include("includes/foot.php");
    ?>
</body>
</html>