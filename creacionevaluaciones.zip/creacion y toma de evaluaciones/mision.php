<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/security.php");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <?php include("includes/head.php"); ?>
</head>
<body>
   <?php
    include("includes/header.php");
    include("includes/menu.php");
    ?>
    
    <main>
       <div class="container">
           <h2>Uniandes</h2>
           <hr>
           <div class="row">
               <div class="col-md-6">
                  <h3>Misión</h3>
                   <p class="mivi">
                       Somos una Universidad particular, que tiene como propósito formar profesionales de tercer y cuarto nivel, de investigación, responsables, competitivos, con conciencia ética y solidaria capaces de contribuir al desarrollo nacional y democrático, mediante una educación humanista, cultural y científica dirigida a bachilleres y profesionales nacionales y extranjeros.
                   </p>
               </div>
               <div class="col-md-6">
                   <h3>visión</h3>
                   <p class="mivi">
                       Ser una institución reconocida a nivel nacional e internacional por su calidad, manteniendo entre sus fortalezas un cuerpo docente de alto nivel académico y un proceso de formación profesional centrado en el estudiante, acorde con los avances científicos, tecnológicos, de investigación en vínculo permanente con los sectores sociales y productivos.
                   </p>
               </div>
           </div>
           <br>
           <br>
           <h2>Unidad Educativa Municipal Ciudad de Quevedo</h2>
           <hr>
           <div class="row">
               <div class="col-md-6">
                  <h3>Misión</h3>
                   <p class="mivi">
                       Somos una institución de Educación Técnica de la Provincia De Los Ríos, de pensamientos libres, creativos y sentido humanista, integrando  entes competentes para el campo laboral y continua formación profesional. Con personal idóneo, dotación tecnológica e infraestructura, para  fomentar las actividades prácticas dirigida a nuestra juventud.
                   </p>
               </div>
               <div class="col-md-6">
                   <h3>visión</h3>
                   <p class="mivi">
                       La Unidad Educativa “Ciudad de Quevedo” con sostenimiento municipal, para el 2021 seremos líderes en el área técnica de servicios y artísticos, incrementando nuevas carreras que contribuyan a nuestra sociedad promoviendo el bachillerato técnico.
                   </p>
               </div>
           </div>
       </div>
        <br>
    </main>
    
    <?php
    include("includes/foot.php");
    include("includes/sweetalertas.php");
    ?>
</body>
</html>