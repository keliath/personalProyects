<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/security.php");

$user = $_SESSION["user"];
$estu = $_GET["est"];

$sql_repo = "select id_nota, a.id_evalua,a.usu_cedula, not_nota,eva_nombre, eva_pregun, a.eva_fecha,eva_fechaf from nota a inner join evaluacion b on a.id_evalua = b.id_evalua where usu_cedula = '$estu' group by id_evalua desc";
$q_repo = mysqli_query($mysqli, $sql_repo);

$sql_est = "select usu_nombre from usuarios where usu_cedula = '$estu'";
$q_est = mysqli_query($mysqli, $sql_est);
$r_est = mysqli_fetch_assoc($q_est);
$est = $r_est["usu_nombre"];
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <?php include("includes/head.php"); ?>
    </head>
    <body>
        <?php
        include("includes/header.php");
        include("includes/menu.php");
        ?>

        <main>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <form action="">
                            <div class="form-group">
                                <?php
                                if(mysqli_num_rows($q_repo) > 0){
                                $r_repo = mysqli_fetch_assoc($q_repo);
                                ?>
                                <table class="tabla">
                                    <thead>
                                        <tr>
                                            <th>Estudiante</th>
                                            <th>Evaluación</th>
                                            <th>Nota</th>
                                            <th>Atrasada</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                    do{
                                        $nom = $r_repo['eva_nombre'];
                                        $nota = $r_repo['not_nota'];
                                        $max = 10;
                                        $fechaR = $r_repo["eva_fecha"];
                                        $fechaI = $r_repo["eva_fechaf"];
                                        $diff = abs(strtotime($fechaR) - strtotime($fechaI));
                                        $atraso = "no";
                                        if($diff > 0){

                                        }else{
                                            $atraso = "si";
                                        }

                                        echo 
                                            "<tr>
                                    <td>$est</td>
                                    <td>$nom</td>
                                    <td>$nota/$max</td>
                                    <td>$atraso</td>
                                </tr>";
                                    }while($r_repo = mysqli_fetch_assoc($q_repo));
                                        ?>
                                    </tbody>
                                </table>
                                <?php
                                    echo "<br><a href='./reportes.php' class='btn btn-primary' style='text-decoration:none'>Volver</a>";

                                }else{
                                    echo "No hay evaluaciones resueltas de estes estudiante";
                                }
                                ?>
                            </div>
                            <div class="form-group" id="display">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>

        <?php
        include("includes/foot.php");
        include("includes/sweetalertas.php");
        ?>
    </body>
</html>