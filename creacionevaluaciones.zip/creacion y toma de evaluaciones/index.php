<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");



//preguntar si hay sesion iniciada ya
if(isset($_SESSION["user"])){
    header("location:./select.php");
}

//
if(isset($_POST['ingresar'])){
    $sql_login = sprintf("select * from usuarios where usu_cedula =  %s and usu_pass = %s and usu_activo = 1",
                         valida::convertir($mysqli, $_POST["ci"],"text"),
                         valida::convertir($mysqli,md5($_POST["pass"]),"text"));
    $q_login = mysqli_query($mysqli, $sql_login);
    $r_login = mysqli_fetch_assoc($q_login);
    $t_login = mysqli_num_rows($q_login);

    if($t_login == 0){
        header("location:./?err");
    }else{
        $_SESSION["user"] = $r_login["usu_cedula"]; 
        $_SESSION["nivel"] = $r_login["usu_nivel"];

        $sql_status = sprintf("UPDATE usuarios SET usu_status = 1 where usu_cedula = %s",
                              valida::convertir($mysqli, $_POST["ci"], "text"));
        $q_status = mysqli_query($mysqli, $sql_status) or die ("error: ".mysqli_error($mysqli));

        header("location:./select.php");
    }
}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <link rel="stylesheet" href="./css/login.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
        <script src="js/sweet.js"></script>
        <script src="js/ajax.js"></script>
    </head>
    <body class="body">
        <main>
            <form action="" method="post" class="form">
                <center><h1>Acceder</h1></center>
                <div class="inputicon">
                    <i class="fa fa-user fa-lg fa-fw" aria-hidden="true"></i>
                    <input type="text" name="ci" placeholder="Ingrese su cedula" value="" autocomplete="off">
                </div>
                <div class="inputicon">
                   <i class="fa fa-lock fa-lg fa-fw" aria-hidden="true"></i>
                    <input type="password" name="pass" placeholder="Ingrese su contraseña" value="" autocomplete="off">
                </div>
                
                <input type="submit" class="ok" name="ingresar" value="Ingresar">
                <?php
                if(isset($_GET["err"])){
                    echo "<span class='error'>usuario incorrecto o no validado</span>";
                }
                if(isset($_GET["sec"])){
                    echo "<span class='error'>usuario no autorizado</span>";
                }
                ?>
                <br>
                <a href="./restorepass.php" id="restorepass">Olvido su contraseña?</a>
                <a href="./registro.php" id="registro"  style="float:right">registrar nuevo usuario</a>
                <div id="display"></div>
            </form>
        </main>
        <?php
        include("./includes/sweetalertas.php");
        ?>
    </body>
</html>