<?php
session_start();

require_once("./clases/conexion.php");
require("./clases/valida.php");
require("./clases/securitypro.php");

$user = $_SESSION["user"];
$sql_profe = "select id_profes from profesor a inner join usuarios b on a.usu_cedula = b.usu_cedula where b.usu_cedula = '$user'";
$q_profe = mysqli_query($mysqli, $sql_profe);
$r_profe = mysqli_fetch_assoc($q_profe);
$idProfe = $r_profe["id_profes"];

$sql_evas = "select * from evaluacion";
$q_evas = mysqli_query($mysqli, $sql_evas);
$r_evas = mysqli_fetch_assoc($q_evas);

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <?php
        include_once("./includes/head.php");
        ?>
    </head>
    <body class="">
        <?php
        include("./includes/header.php");
        include("./includes/menu.php");
        ?>

        <main>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <form action="">
                            <div class="form-group">
                                <?php
                                if(mysqli_num_rows($q_evas) > 0){
                                ?>
                                <table class="tabla">
                                    <thead>
                                        <tr>
                                            <th>Evaluación</th>
                                            <th>Opciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                    do{
                                        $nom = $r_evas['eva_nombre'];
                                        $id = $r_evas['id_evalua'];
                                        echo 
                                            "<tr>
                                                        <td>$nom</td>
                                                        <td>
                                                            <a href='verpregs.php?eva=$id'>
                                                                Ver
                                                            </a>
                                                            <a href='delpru.php?id=$id'>
                                                                Borrar
                                                            </a>
                                                        </td>
                                                    </tr>";
                                    }while($r_evas = mysqli_fetch_assoc($q_evas));
                                        ?>
                                    </tbody>
                                </table>
                                <?php
                                    echo "<br><a href='./' class='btn btn-primary' style='text-decoration:none'>Volver</a>";

                                }else{
                                    echo "No hay evaluaciones, de click <a href='./neweva.php'>aquí</a> para crear una";
                                }
                                ?>
                            </div>
                            <div class="form-group" id="display">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>

        <?php
        require_once("./includes/sweetalertas.php");
        ?>
    </body>
</html>