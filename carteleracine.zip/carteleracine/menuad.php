<nav>
    <a href="./">Home</a>
    <a href="./newpeli.php">Nueva pelicula</a>
    <a href="./selectpeli.php?inf">Modificar pelicula</a>
    <a href="./selectpeli.php?h">Modificar Horarios</a>
    <a href="./close.php" class="cerrar">cerrar sesion</a>
    
</nav><br>