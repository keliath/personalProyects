<header>
    <div>
        <img src="./images/logo.png" alt="wao">
    </div>
</header>

<footer>
    <p>derechos reservados &copy;</p>
</footer>