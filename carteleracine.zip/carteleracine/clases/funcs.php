<?php
function remplazar($reemplazar, $reemplazo, $texto){
    $len = strlen($texto);
    for($x=0;$x<$len;$x++){
        
    }
}
?>